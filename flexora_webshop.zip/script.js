
// Smooth scroll is via CSS 'scroll-behavior: smooth'
console.log('Flexora script actief');
